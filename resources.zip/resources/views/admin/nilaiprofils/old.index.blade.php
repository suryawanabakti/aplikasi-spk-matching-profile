@extends('layouts.app')

@section('content')
<section class="section">
    <div class="section-header">
        <h1>Nilai Profils</h1>
        <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="#">Nilai Profils</a></div>
            <div class="breadcrumb-item">Index</div>
        </div>
    </div>
    <div class="section-body">
        <div class="section-title">Data Nilai Profils</div>
        <p class="section-lead">
            ini adalah table Nilai Profil.
        </p>


        <div class="row">
            <div class="col">
                <div class="card">
                    <div class="card-header">
                        <h4>Kriteria Table</h4>
                        <div class="card-header-action">
                         
                            <a href="javascript:void(0)" data-toggle="modal" data-target="#modalAddRange"  class="btn btn-primary"><i class="fas fa-user-plus"></i> Create </a>
                            
                            <div class="btn-group">
                                <a href="#" class="btn btn-primary"><i class="fas fa-file-import"></i> Import</a>
                                <a href="#" class="btn btn-primary"><i class="fas fa-file-export"></i> Export</a>
                               
                            </div>
                            
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped" id="kriteriaTable">
                              <thead>
                                <tr>
                                  <th class="text-center">
                                    #
                                  </th>
                                  <th>Kecamatan</th>
                                  <th>Kriteria</th>
                                  <th>Sub Kriteria</th>
                                  <th>Nilai Profil</th>
                                  <th>Actions</th>
                                </tr>
                              </thead>
                              <tbody>
                                @foreach ($nilai_profils as $nilai_profil)
                                <tr>
                                    <td>
                                      {{ $loop->iteration }}
                                    </td>
                                    <td>{{ $nilai_profil->kecamatan->name }}</td>
                                    <td>{{ $nilai_profil->dataranges->kriteria->name }}</td>
                                    <td>{{ $nilai_profil->dataranges->nama_sub_kriteria }}</td>
                                    <td>{{ $nilai_profil->dataranges->nilai }}</td>
                                    <td><a href="/nilai-profils/destroy/{{ $nilai_profil->id }}" onclick="return confirm('Apakah anda yakin ?')" class="btn btn-danger">hapus</a></td>
                                  </tr>
                                @endforeach
                              </tbody>
                            </table>
                          </div>
                    </div>
                    <div class="card-footer text-center justify-content-center">
                      <a href="/hitung" class="btn btn-success">CARI RANKING BERDASARKAN TABLE NILAI PROFIL</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection

@push('js')
<script>
    $(document).ready(() => {
        $('#kriteriaTable').DataTable()
    })
</script>
    
@endpush

@section('modal')

<!-- Modal -->
<div class="modal fade" id="modalAddRange" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Tambah data kritera</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
      <form action="/nilai-profils" method="POST">
        @csrf
      <div class="modal-body">
        <div class="form-group">
          <label for="">Kecamatan</label>
          <select name="kecamatan_id" id="kecamatan_id" class="form-control">
            @foreach ($kecamatans as $kecamatan)
              <option value="{{ $kecamatan->id }}">{{ $kecamatan->name }}</option>
        `   @endforeach  
          </select>
        </div>
        <div class="form-group">
          <label for="">Range Kritera</label>
          <select name="data_range_kriteria_id" id="data_range_kriteria_id" class="form-control">
            <option value="0">Pilih Sub Kriteria</option>
            @foreach ($data_ranges as $data_range)
              <option value="{{ $data_range->id }}"><b class="font-weight-bold">{{ $data_range->kriteria->name  }}</b>, Sub Kriteria {{ $data_range->nama_sub_kriteria }}</option>
        `   @endforeach  
          </select>

          <div class="mt-4"> Nilai Profil :<b id="nilai_profil"></b> </div> 


        </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save changes</button>
      </div>
    </form>
    </div>
  </div>
</div>
@endsection

@push('js')
  <script>
    $('#data_range_kriteria_id').on('change', () => {
      var id_range_kriteria = $('#data_range_kriteria_id').val()

      $.ajax({
        url: "/nilai-profils/datarange/" +id_range_kriteria,
        type: 'GET',
        dataType: 'json', // added data type
        success: function(res) {
            $('#nilai_profil').html(res.nilai)
        }
    });

    })
  </script>
@endpush