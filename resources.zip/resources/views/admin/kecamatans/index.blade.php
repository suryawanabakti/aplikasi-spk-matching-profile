@extends('layouts.app')

@section('content')
<section class="section">
    <div class="section-header">
        <h1>Kecamatan</h1>
        <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="#">Kecamatan</a></div>
            <div class="breadcrumb-item">Index</div>
        </div>
    </div>
    <div class="section-body">
        <div class="section-title">Data Kecamatan</div>
        <p class="section-lead">
            ini adalah table Kecamatan.
        </p>


        <div class="row">
            <div class="col">
                <div class="card">
                    <div class="card-header">
                        <h4>Kecamatan Table</h4>
                        <div class="card-header-action">

                            <a href="javascript:void(0)" data-toggle="modal" data-target="#modalAddKritera"  class="btn btn-primary"><i class="fas fa-user-plus"></i> Create </a>

                            <div class="btn-group">
                                <a href="#" class="btn btn-primary"><i class="fas fa-file-import"></i> Import</a>
                                <a href="#" class="btn btn-primary"><i class="fas fa-file-export"></i> Export</a>
                            </div>
                            
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped" id="kriteriaTable">
                              <thead>
                                <tr>
                                  <th class="text-center">
                                    #
                                  </th>
                                  <th>Tanggal Kejadian</th>
                                  <th>Name</th>
                                  <th>Action</th>
                                </tr>
                              </thead>
                              <tbody>
                                @foreach ($kecamatans as $kecamatan)
                                <tr>
                                    <td>
                                      {{ $loop->iteration }}
                                    </td>
                                    <td>{{ $kecamatan->tgl_kejadian }}</td>
                                    <td>{{ $kecamatan->name }}</td>
                                   
                                    <td><a href="/data-kecamatans/destroy/{{ $kecamatan->id }}" onclick="return confirm('Apakah anda yakin ?')" class="btn btn-danger">hapus</a></td>
                                  </tr>
                                @endforeach
                              </tbody>
                            </table>
                          </div>
                    </div>
                  
                </div>
            </div>
        </div>
    </div>
</section>
@endsection

@push('js')
<script>
    $(document).ready(() => {
        $('#kriteriaTable').DataTable()
    })
</script>
    
@endpush

@section('modal')

<!-- Modal -->
<div class="modal fade" id="modalAddKritera" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Tambah data kecamatan</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
      <form action="/data-kecamatans" method="POST">
        @csrf
      <div class="modal-body">
        <div class="form-group">
          <label for="">Tanggal Kejadian</label>
          <input type="date" name="tgl_kejadian" id="tgl_kejadian" class="form-control">
        </div>
         <div class="form-group">
          <label for="">Nama kecamatan</label>
          <input type="text" name="name" id="name" class="form-control">
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save changes</button>
      </div>
    </form>
    </div>
  </div>
</div>
@endsection